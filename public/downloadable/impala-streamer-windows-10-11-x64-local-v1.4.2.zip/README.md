# Impala Streamer — Local Edition

The itch.io edition runs without GitHub, Netlify, an Impala account, or an
internet connection. The native Impala process serves the player and the media
library directly from the primary computer.

## Windows 10/11

1. Extract `Impala-Streamer-Windows-10-11-x64.zip`.
2. Double-click **Install Impala.cmd**. Keep the window open if it reports an error.
3. Allow Impala through Windows Firewall for **Private networks** when asked.
4. Impala opens at `http://127.0.0.1:8089` and creates a desktop shortcut.

The installer checks for FFmpeg and FFprobe. When they are missing and Windows
Package Manager is available, it explains the optional features and asks for
permission before downloading anything. Type **Y** to approve installation for
the current user or **N** to skip it. This step requires internet access. If it
is declined or cannot complete, ordinary MP3 and MP4 playback still works; only
MKV preparation and video conversion remain unavailable until FFmpeg is installed.

## Other platforms

A native Intel Mac host edition is planned. Until additional host editions are
released, macOS, Linux, Raspberry Pi, tablets, and other devices can connect to
the Windows host as browser-based satellites.

## Choose the library

On Windows, Impala initially uses `C:\Users\<UserID>\Music` when that folder
exists. To serve a different dedicated media folder, such as `D:\Music`, open
**Settings → Local Library Companion**, enter the complete folder path, and
click **Connect Library**. Impala scans the selected folder and serves that
library to the primary computer and paired devices on the local network. Large
libraries can take a little time to scan.

The selected folder is saved locally and restored when Impala restarts. The
current release serves one selected library root at a time; connecting a new
root replaces the previously served root without changing or deleting any
media files.

## Recommended library organization

Impala can serve audio and video from the same selected root. For predictable
grouping, create separate `Audio` and `Video` folders and use a consistent
hierarchy:

```text
D:\Impala Library\
|-- Audio\
|   |-- Artist Name\
|       |-- Album Name\
|           |-- 01 - Track Title.mp3
|           |-- 02 - Track Title.mp3
|
|-- Video\
    |-- Movies\
    |   |-- Movie Title (2025)\
    |       |-- Movie Title (2025).mp4
    |
    |-- TV\
        |-- Series Name\
            |-- Season 01\
                |-- Series Name - S01E01 - Episode Title.mkv
                |-- Series Name - S01E02 - Episode Title.mkv
```

Recommended conventions:

- Music: `Artist Name\Album Name\01 - Track Title.ext`
- Television: `Series Name\Season 01\Series Name - S01E01 - Episode Title.ext`
- Movies: place each movie in its own folder and include the release year when useful.
- Use leading zeroes for track, season, and episode numbers.
- The two folder levels immediately above a media file influence its displayed artist/series and album/season grouping.
- Do not select an entire drive or the whole user-profile folder as the root.
- Do not manually create filenames containing `.impala.`; Impala reserves that pattern for prepared media and timing information.

After organizing the folders, select `D:\Impala Library` in
**Settings → Local Library Companion** and click **Connect Library**.

## Connect another device on the LAN

At startup, Impala displays one or more private-network URLs and a six-digit
pairing code on the primary computer. On another computer or device connected
to the same network, open one of those URLs in a browser. The Impala player
interface appears immediately; it does not request the pairing code on the
opening screen. Click **Library**. When the remote browser first requests the
protected library, Impala asks for the six-digit code shown on the primary
computer. Enter that code to view and play the host library. A successfully
paired device remains trusted in that browser unless its site data is cleared.

Only use Impala on a trusted private network. Never forward port 8089 through a
router or expose it directly to the internet.

The primary computer must remain running and awake while other devices use its
library. If its local IP address changes after a router or network restart, use
the new private-network URL displayed by Impala. Guest Wi-Fi, client-isolation
settings, corporate networks, and some VPNs may prevent devices from reaching
each other even when they appear to use the same Wi-Fi name.

## Supported media and playback

The library scanner recognizes MP3, FLAC, WAV, AAC, M4A, OGG, MP4, M4V, WebM,
MOV, and MKV files. Actual playback depends on the codecs supported by the
satellite device and its browser. H.264 video with AAC audio in an MP4 container
provides the broadest browser compatibility.

FFmpeg and FFprobe enable MKV preparation, audio compatibility conversion,
Voice Sync output, and corrected MP4 copies. Impala saves generated `.impala`
files beside the source media and never overwrites the original file.

## Rescanning and changing libraries

To include newly added media or rebuild the served catalog, open
**Settings → Local Library Companion** and click **Connect Library** again. To
change libraries, enter another dedicated root and reconnect. Paired satellite
devices may need to reopen or refresh **Library** to see the updated catalog.

## Quick troubleshooting

- **The installer window closes or reports an error:** extract the complete ZIP, then run **Install Impala.cmd** rather than the PowerShell file directly.
- **Another device cannot open Impala:** confirm both devices are on the same private network, keep the host awake, allow Impala through Windows Firewall for private networks, and temporarily disconnect restrictive VPNs.
- **The interface opens but Library requests a code:** this is expected on a new satellite. Enter the current six-digit code shown by the host.
- **The interface opens but Library cannot connect:** verify the host is still running and use its current `192.168.x.x:8089` or other displayed private-network address—not `127.0.0.1:8089` on the satellite.
- **MKV or conversion features are unavailable:** rerun the installer and approve FFmpeg, or install FFmpeg and FFprobe separately.
- **A format appears but will not play:** test an H.264/AAC MP4 or use FFmpeg preparation; browser codec support varies by device.
- **New files do not appear:** reconnect the selected library root to rescan it, then refresh Library on the satellite.

## Privacy and local data

Media stays on the host computer and is served only to paired devices on the
local network. Preferences, playlists, playback information, pairing data, and
the selected library root are stored locally. Clearing a browser's site data
removes that browser's local Impala state and may require pairing it again.

## Optional cloud capabilities

Cloud Signer/Library, Coast to Coast, Sync Play, live streaming, and external
metadata remain supported but ship with no service URLs and are off by default.
They make no cloud request until the owner explicitly configures and enables
the corresponding feature in Settings.
