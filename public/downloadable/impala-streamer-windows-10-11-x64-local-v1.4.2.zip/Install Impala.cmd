@echo off
setlocal
title Impala Streamer Installer
echo Installing Impala Streamer...
echo.
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-Impala.ps1"
set "IMPALA_INSTALL_EXIT=%ERRORLEVEL%"
echo.
if not "%IMPALA_INSTALL_EXIT%"=="0" (
  echo Installation did not complete. Please copy this window or take a screenshot.
) else (
  echo Installation completed successfully.
)
echo.
pause
exit /b %IMPALA_INSTALL_EXIT%
