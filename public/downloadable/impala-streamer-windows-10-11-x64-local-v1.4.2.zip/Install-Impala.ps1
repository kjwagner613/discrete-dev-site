param(
  [string]$InstallRoot = (Join-Path $env:LOCALAPPDATA "Impala Streamer"),
  [switch]$NoLaunch,
  [switch]$NoShortcut,
  [switch]$SkipMediaTools
)

$ErrorActionPreference = "Stop"
$source = Split-Path -Parent $MyInvocation.MyCommand.Path

Write-Host "Source: $source"
Write-Host "Installing to: $installRoot"

if (-not (Test-Path -LiteralPath (Join-Path $source "Impala-Streamer.exe"))) {
  throw "Impala-Streamer.exe is missing. Extract the entire ZIP before running the installer."
}
if (-not (Test-Path -LiteralPath (Join-Path $source "web\index.html"))) {
  throw "The Impala web files are missing. Extract the entire ZIP before running the installer."
}

Get-Process -Name "Impala-Streamer" -ErrorAction SilentlyContinue | ForEach-Object {
  if ($_.Path -and $_.Path.StartsWith($installRoot, [StringComparison]::OrdinalIgnoreCase)) {
    Write-Host "Closing the installed Impala process for a safe update..."
    Stop-Process -Id $_.Id -Force
    $_.WaitForExit()
  }
}

New-Item -ItemType Directory -Path $installRoot -Force | Out-Null
$installedWeb = Join-Path $installRoot "web"
if (Test-Path -LiteralPath $installedWeb) {
  Remove-Item -LiteralPath $installedWeb -Recurse -Force
}
Copy-Item (Join-Path $source "Impala-Streamer.exe") $installRoot -Force
Copy-Item (Join-Path $source "web") $installRoot -Recurse -Force

if (-not (Test-Path -LiteralPath (Join-Path $installRoot "web\index.html"))) {
  throw "Installation verification failed: web\index.html was not copied."
}

function Find-ImpalaMediaTools {
  $ffmpeg = Get-Command "ffmpeg.exe" -ErrorAction SilentlyContinue
  $ffprobe = Get-Command "ffprobe.exe" -ErrorAction SilentlyContinue
  if ($ffmpeg -and $ffprobe) {
    return @($ffmpeg.Source, $ffprobe.Source)
  }

  $wingetRoot = Join-Path $env:LOCALAPPDATA "Microsoft\WinGet"
  if (Test-Path -LiteralPath $wingetRoot) {
    $ffmpegFile = Get-ChildItem -LiteralPath $wingetRoot -Filter "ffmpeg.exe" -File -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($ffmpegFile) {
      $ffprobeFile = Join-Path $ffmpegFile.DirectoryName "ffprobe.exe"
      if (Test-Path -LiteralPath $ffprobeFile) {
        return @($ffmpegFile.FullName, $ffprobeFile)
      }
    }
  }
  return @()
}

if (-not $SkipMediaTools) {
  Write-Host "Checking FFmpeg and FFprobe..."
  $mediaTools = @(Find-ImpalaMediaTools)
  if ($mediaTools.Count -ge 2) {
    Write-Host "FFmpeg and FFprobe are ready."
  }
  else {
    $winget = Get-Command "winget.exe" -ErrorAction SilentlyContinue
    if ($winget) {
      Write-Host "FFmpeg is optional. It enables MKV preparation, video compatibility conversion, and Voice Sync output."
      Write-Host "Installing it uses Windows Package Manager and requires internet access."
      $permission = Read-Host "Install FFmpeg for the current user now? Type Y to approve or N to skip"
      if ($permission -match "^[Yy]$") {
        Write-Host "Installing FFmpeg with Windows Package Manager..."
        $wingetArguments = @(
          "install", "--id", "Gyan.FFmpeg", "--exact", "--scope", "user",
          "--accept-package-agreements", "--accept-source-agreements", "--disable-interactivity"
        )
        $wingetProcess = Start-Process -FilePath $winget.Source -ArgumentList $wingetArguments -Wait -PassThru -NoNewWindow
        $mediaTools = @(Find-ImpalaMediaTools)
        if ($wingetProcess.ExitCode -eq 0 -and $mediaTools.Count -ge 2) {
          Write-Host "FFmpeg and FFprobe were installed successfully."
        }
        else {
          Write-Warning "FFmpeg could not be installed automatically. Impala will still play normal MP3 and MP4 files, but MKV preparation and Voice Sync conversion will be unavailable until FFmpeg is installed."
        }
      }
      else {
        Write-Host "FFmpeg installation skipped. Normal MP3 and MP4 playback remains available."
      }
    }
    else {
      Write-Warning "Windows Package Manager is unavailable, so FFmpeg could not be installed automatically. Impala will still play normal MP3 and MP4 files. Install App Installer from Microsoft, then run this installer again to enable MKV preparation and Voice Sync conversion."
    }
  }
}

if (-not $NoShortcut) {
  try {
    $shell = New-Object -ComObject WScript.Shell
    $shortcut = $shell.CreateShortcut((Join-Path ([Environment]::GetFolderPath("Desktop")) "Impala Streamer.lnk"))
    $shortcut.TargetPath = Join-Path $installRoot "Impala-Streamer.exe"
    $shortcut.WorkingDirectory = $installRoot
    $shortcut.Description = "Impala Streamer - local media for this computer and LAN"
    $shortcut.Save()
  }
  catch {
    Write-Warning "Impala installed, but the desktop shortcut could not be created: $($_.Exception.Message)"
  }
}

if (-not $NoLaunch) {
  Start-Process (Join-Path $installRoot "Impala-Streamer.exe") -WorkingDirectory $installRoot
}
Write-Host "Impala Streamer is installed successfully."
