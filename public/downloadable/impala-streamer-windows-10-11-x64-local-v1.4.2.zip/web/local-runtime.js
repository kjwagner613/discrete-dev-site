(() => {
  if (window.KW_PLAYER_CONFIG?.localEdition !== true || !/^https?:$/.test(window.location.protocol)) return;

  const nativeFetch = window.fetch.bind(window);
  let pairingPromise = null;

  function isSameOrigin(input) {
    try {
      const value = typeof input === "string" ? input : input?.url;
      return new URL(value, window.location.href).origin === window.location.origin;
    } catch (_) {
      return false;
    }
  }

  async function pairThisDevice() {
    const code = window.prompt("Enter the six-digit pairing code shown by Impala on the primary computer:");
    if (!code) return false;
    const response = await nativeFetch("/pair", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ code: String(code).trim() })
    });
    if (!response.ok) {
      window.alert("That pairing code was not accepted. Check the primary computer and try again.");
      return false;
    }
    return true;
  }

  window.fetch = async (input, init) => {
    let response = await nativeFetch(input, init);
    if (response.status !== 401 || !isSameOrigin(input) || new URL(typeof input === "string" ? input : input.url, location.href).pathname === "/pair") {
      return response;
    }
    pairingPromise ||= pairThisDevice().finally(() => { pairingPromise = null; });
    if (await pairingPromise) response = await nativeFetch(input, init);
    return response;
  };

  document.addEventListener("DOMContentLoaded", async () => {
    try {
      const response = await nativeFetch("/local-info", { cache: "no-store" });
      if (!response.ok) return;
      const info = await response.json();
      const urls = Array.isArray(info.lanUrls) ? info.lanUrls : [];
      if (!urls.length) return;
      const panel = document.createElement("aside");
      panel.setAttribute("role", "status");
      panel.style.cssText = "position:fixed;right:12px;bottom:12px;z-index:10000;max-width:390px;padding:12px 14px;border:1px solid #d6a84b;border-radius:10px;background:#17120d;color:#fff4d6;font:14px/1.4 system-ui;box-shadow:0 8px 28px #0008";
      const urlText = urls.map((url) => `<code>${url}</code>`).join("<br>");
      panel.innerHTML = `<strong>Share on this private network</strong><br>${urlText}<br>Pairing code: <strong style="font-size:1.25em;letter-spacing:.12em">${String(info.pairCode || "")}</strong><button type="button" aria-label="Close network information" style="float:right;margin-left:12px">×</button>`;
      panel.querySelector("button")?.addEventListener("click", () => panel.remove());
      document.body.appendChild(panel);
    } catch (_) {}
  });
})();
