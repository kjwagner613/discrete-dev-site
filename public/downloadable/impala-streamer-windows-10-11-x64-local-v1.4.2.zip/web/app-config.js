window.KW_PLAYER_CONFIG = window.KW_PLAYER_CONFIG || {
  // The downloadable edition is local-only by default. Cloud services remain
  // supported, but are activated only when a user explicitly supplies them.
  apiBaseUrl: "",
  liveStreamApiBaseUrl: "",
  localLiveStreamApiBaseUrl: "",
  syncPlayApiBaseUrl: "",
  coastApiBaseUrl: "",
  metadataApiUrl: "",
  localEdition: true,
  authStorageKey: "impalaStreamer.authSession",
  playlistStoragePrefix: "impalaStreamer",
  instanceStorageId: "",
  builtInPlaylistsEnabled: true,
  enabledBuiltInPlaylistIds: ["songs"],
  brandName: "Impala Streamer",
  // Change per deployment, e.g. "Impala Family Streamer" or "Impala Partner Streamer".
  editionName: "Impala Streamer",
  appVersion: "1.2.0",
  appBuildDate: "2026.08.13",
  mkvPlaybackEnabled: true,
  localHelperDownloadUrl: ""
};

window.ImpalaConfig = window.ImpalaConfig || (() => {
  const config = window.KW_PLAYER_CONFIG || {};

  function cleanStorageSegment(value) {
    return String(value || "").trim().replace(/[^a-z0-9._:-]/gi, "-").replace(/^-+|-+$/g, "");
  }

  function getStoragePrefix() {
    const basePrefix = cleanStorageSegment(config.playlistStoragePrefix) || "impalaStreamer";
    const instanceStorageId = cleanStorageSegment(config.instanceStorageId);
    return instanceStorageId ? `${basePrefix}.${instanceStorageId}` : basePrefix;
  }

  function getAuthStorageKey() {
    if (config.authStorageKey && !config.instanceStorageId) {
      return String(config.authStorageKey);
    }

    return `${getStoragePrefix()}.authSession`;
  }

  const preferencesKey = `${getStoragePrefix()}.uiPreferences`;

  function readPreferences() {
    try {
      const rawPreferences = localStorage.getItem(preferencesKey);
      return rawPreferences ? JSON.parse(rawPreferences) : {};
    } catch (error) {
      console.error("Unable to read Impala runtime preferences:", error);
      return {};
    }
  }

  function cleanUrl(value) {
    return String(value || "").trim().replace(/\/+$/, "");
  }

  function getCloudApiBaseUrl() {
    const preferences = readPreferences();
    return cleanUrl(preferences.cloudApiBaseUrl || config.apiBaseUrl || "");
  }

  function getLiveStreamApiBaseUrl() {
    const hostname = window.location?.hostname || "";
    const isLocalPreview = hostname === "localhost" || hostname === "127.0.0.1" || hostname === "::1";
    const configuredUrl = config.liveStreamApiBaseUrl || (isLocalPreview ? config.localLiveStreamApiBaseUrl : "");
    return cleanUrl(configuredUrl);
  }

  function getSyncPlayApiBaseUrl() {
    const preferences = readPreferences();
    return cleanUrl(preferences.syncPlayApiBaseUrl || config.syncPlayApiBaseUrl || "");
  }

  function getCoastApiBaseUrl() {
    const preferences = readPreferences();
    return cleanUrl(preferences.coastApiBaseUrl || config.coastApiBaseUrl || "");
  }

  function getInstanceId() {
    const preferences = readPreferences();
    return String(preferences.instanceId || "").trim();
  }

  function getMetadataApiUrl() {
    const preferences = readPreferences();
    if (preferences.metadataEnabled !== true) return "";
    const configuredUrl = String(config.metadataApiUrl || "").trim().replace(/\/+$/, "");
    if (configuredUrl) return configuredUrl;
    const hostname = String(window.location?.hostname || "").toLowerCase();
    return hostname.endsWith(".netlify.app") ? "/api/metadata" : "";
  }

  function isMkvPlaybackEnabled() {
    return config.mkvPlaybackEnabled === true;
  }

  function areBuiltInPlaylistsEnabled() {
    return config.builtInPlaylistsEnabled === true;
  }

  function getEnabledBuiltInPlaylistIds() {
    if (!areBuiltInPlaylistsEnabled()) {
      return [];
    }

    return Array.isArray(config.enabledBuiltInPlaylistIds)
      ? config.enabledBuiltInPlaylistIds.map((playlistId) => String(playlistId))
      : [];
  }

  return {
    preferencesKey,
    getStoragePrefix,
    getAuthStorageKey,
    getCloudApiBaseUrl,
    getLiveStreamApiBaseUrl,
    getSyncPlayApiBaseUrl,
    getCoastApiBaseUrl,
    getMetadataApiUrl,
    getInstanceId,
    isMkvPlaybackEnabled,
    areBuiltInPlaylistsEnabled,
    getEnabledBuiltInPlaylistIds
  };
})();
